package com.example.sanfrancisco21.Tienda;

import android.graphics.Paint;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.example.sanfrancisco21.MainActivity;
import com.example.sanfrancisco21.RoundedButton;
import com.example.sanfrancisco21.Session.BBDD;
import com.example.sanfrancisco21.R;
import com.example.sanfrancisco21.databinding.ActivityMainBinding;
import com.example.sanfrancisco21.databinding.LoginLayoutBinding;

import java.security.ProtectionDomain;
import java.util.ArrayList;
import java.util.Collections;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link TiendaFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class TiendaFragment extends Fragment {

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    private String oferta = "0";

    public TiendaFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment TiendaFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static TiendaFragment newInstance(String param1, String param2) {
        TiendaFragment fragment = new TiendaFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_tienda, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        // Instanciamos el contenedor y lo vaciamos
        LinearLayout scroll_layout = view.findViewById(R.id.tienda_scroll_layout);
        scroll_layout.removeAllViews();

        //BBDD
        BBDD db = new BBDD(getActivity());

        //Recuperar los productos y ordenarlos por beneficio
        ArrayList<Producto> productos = db.getProductList();

        //Header del layout
        TextView header_tienda = new TextView(getActivity());
        header_tienda.setText("Productos Hotel San Francisco");
        header_tienda.setTextSize(40);
        header_tienda.setTextColor(getResources().getColor(R.color.white));
        header_tienda.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
        scroll_layout.addView(header_tienda);

        //layout para los productos
        LinearLayout header_sep = new LinearLayout(getActivity());
        header_sep.setBackgroundColor(getResources().getColor(R.color.dorado));
        header_sep.setMinimumHeight(7);
        LinearLayout.LayoutParams separadorLP = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        separadorLP.setMargins(0,25,0,0);
        header_sep.setLayoutParams(separadorLP);
        scroll_layout.addView(header_sep);

        //Añadir banner oferta
        MainActivity mainActivity = (MainActivity) getActivity();
        if(mainActivity.getOfertaAsociada()!=null){
            switch (mainActivity.getOfertaAsociada()){
                case "1":
                    ImageView imageView = new ImageView(getActivity());
                    imageView.setImageResource(R.drawable.aprovecha_las_ofertas_de_sanvalentin);
                    scroll_layout.addView(imageView);
                    this.oferta = "SanValentin";
                    break;
                case "2":
                    ImageView imageView2 = new ImageView(getActivity());
                    imageView2.setImageResource(R.drawable.aprovecha_las_ofertas_de_semana_santa);
                    scroll_layout.addView(imageView2);
                    this.oferta = "SemanaSanta";
                    break;
                case "3":
                    ImageView imageView3 = new ImageView(getActivity());
                    imageView3.setImageResource(R.drawable.aprovecha_las_ofertas_de_reyesmagos);
                    scroll_layout.addView(imageView3);
                    this.oferta = "ReyesMagos";
                    break;
                case "0": break;
            }
        }

        //Añadir productos a la tienda
        for(int i=0;i<productos.size();i++){
            LinearLayout layout = new LinearLayout(getActivity());
            layout.setOrientation(LinearLayout.VERTICAL);
            LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            layoutParams.setMargins(0,190,0,0);
            layout.setLayoutParams(layoutParams);
            layout.setBackground(getResources().getDrawable(R.drawable.image_border));

            //vincular imagen del producto
            ImageView img = new ImageView(getActivity());
            switch (productos.get(i).getId()){
                case 1:img.setImageResource(R.drawable.producto1); break;
                case 2:img.setImageResource(R.drawable.producto2); break;
                case 3:img.setImageResource(R.drawable.producto3); break;
                case 4:img.setImageResource(R.drawable.producto4); break;
                case 5:img.setImageResource(R.drawable.producto5); break;
                case 6:img.setImageResource(R.drawable.producto6); break;
                case 7:img.setImageResource(R.drawable.producto7); break;
                case 8:img.setImageResource(R.drawable.producto8); break;
                case 9:img.setImageResource(R.drawable.producto9); break;
                case 10:img.setImageResource(R.drawable.producto10); break;
                case 11:img.setImageResource(R.drawable.producto11); break;
            }
            img.setMaxWidth(150);
            img.setMaxHeight(150);


            //Textview para el nombre del producto
            TextView nombre = new TextView(getActivity());
            nombre.setText(productos.get(i).getNombre()+":");
            nombre.setTextColor(getResources().getColor(R.color.white));
            nombre.setTextSize(25);
            LinearLayout.LayoutParams layoutParamsName = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT,LinearLayout.LayoutParams.WRAP_CONTENT);
            layoutParamsName.setMargins(25,0,25,0);
            nombre.setLayoutParams(layoutParamsName);
            nombre.setLayoutParams(layoutParamsName);

            //Textview para el precio del producto
            TextView precio = new TextView(getActivity());
            precio.setText(""+productos.get(i).getPrecioVenta()+"€");
            precio.setTextColor(getResources().getColor(R.color.white));
            precio.setTextSize(25);
            LinearLayout.LayoutParams layoutParamsPrice = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT,LinearLayout.LayoutParams.WRAP_CONTENT);
            layoutParamsPrice.setMargins(25,0,25,0);
            precio.setLayoutParams(layoutParamsPrice);

            //Textview para la descripcion del producto
            TextView desc = new TextView(getActivity());
            desc.setText(productos.get(i).getDescripcion());
            desc.setTextColor(getResources().getColor(R.color.gray));
            desc.setTextSize(20);
            LinearLayout.LayoutParams layoutParamsDesc = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT,LinearLayout.LayoutParams.WRAP_CONTENT);
            layoutParamsDesc.setMargins(25,30,25,30);
            desc.setLayoutParams(layoutParamsDesc);

            //Boton de compra
            Button compra = new RoundedButton(getActivity());
            compra.setText("Comprar");
            compra.setTextColor(getResources().getColor(R.color.white));
            LinearLayout.LayoutParams layoutParamsBtn = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,LinearLayout.LayoutParams.WRAP_CONTENT);
            layoutParamsBtn.setMargins(25,30,25,30);
            compra.setLayoutParams(layoutParamsBtn);


            //Separador para el scroll
            LinearLayout separador = new LinearLayout(getActivity());
            separador.setBackgroundColor(getResources().getColor(R.color.dorado));
            separador.setMinimumHeight(7);
            LinearLayout.LayoutParams separadorLP2 = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            separadorLP2.setMargins(0,25,0,0);
            separador.setLayoutParams(separadorLP2);

            //Añadir las views
            layout.addView(img);
            layout.addView(nombre);
            if(!(this.oferta.equals("0")) && productos.get(i).getOfertaAsociada().equals(this.oferta)){
                precio.setPaintFlags(nombre.getPaintFlags() |   Paint.STRIKE_THRU_TEXT_FLAG);

                //Textview para el precio del producto
                TextView precioOferta = new TextView(getActivity());
                double p = (productos.get(i).getPrecioVenta())*0.9;
                precioOferta.setText(p+"€");
                precioOferta.setTextColor(getResources().getColor(R.color.white));
                precioOferta.setTextSize(25);
                LinearLayout.LayoutParams layoutParamsPriceOferta = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT,LinearLayout.LayoutParams.WRAP_CONTENT);
                layoutParamsPriceOferta.setMargins(0,0,25,0);
                precioOferta.setLayoutParams(layoutParamsPriceOferta);

                TextView textView = new TextView(getActivity());
                textView.setText(this.oferta + " -10%");
                textView.setTextColor(getResources().getColor(R.color.primary));
                textView.setTextSize(25);

                LinearLayout layoutPrecioOferta = new LinearLayout(getActivity());
                layoutPrecioOferta.setOrientation(LinearLayout.HORIZONTAL);
                layoutPrecioOferta.addView(precio);
                layoutPrecioOferta.addView(precioOferta);
                layoutPrecioOferta.addView(textView);
                layout.addView(layoutPrecioOferta);
            }
            else {
                layout.addView(precio);
            }
            layout.addView(desc);
            layout.addView(compra);
            layout.addView(separador);
            scroll_layout.addView(layout);
        }
    }
}
package com.example.sanfrancisco21;

import android.content.Context;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;

public class RoundedButton extends androidx.appcompat.widget.AppCompatButton {

    public RoundedButton(Context context) {
        super(context);
        setRoundedBackground();
    }

    private void setRoundedBackground() {
        float cornerRadius = 30; // Set your desired corner radius in pixels

        // Create a GradientDrawable with a solid color and rounded corners
        GradientDrawable gradientDrawable = new GradientDrawable();
        gradientDrawable.setColor(getResources().getColor(R.color.primary)); // Set your desired background color
        gradientDrawable.setCornerRadius(cornerRadius);

        // Set the background drawable for the button
        setBackground(gradientDrawable);

        // You can also set other properties if needed
        setGravity(Gravity.CENTER);
    }
}
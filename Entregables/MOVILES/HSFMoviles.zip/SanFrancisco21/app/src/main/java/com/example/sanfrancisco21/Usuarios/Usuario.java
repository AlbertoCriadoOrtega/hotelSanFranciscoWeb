package com.example.sanfrancisco21.Usuarios;

import android.widget.Toast;

import java.util.ArrayList;

public class Usuario {

    private String password;
    private String username;
    private String id;
    private String colorFavorito;
    private String empleo;
    private String estadoCivil;
    private String situacionFinanciera;

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    private String nombre;
    private String apellido;

    public String getColorFavorito() {
        return colorFavorito;
    }

    public void setColorFavorito(String colorFavorito) {
        this.colorFavorito = colorFavorito;
    }

    public String getEmpleo() {
        return empleo;
    }

    public void setEmpleo(String empleo) {
        this.empleo = empleo;
    }

    public String getEstadoCivil() {
        return estadoCivil;
    }

    public void setEstadoCivil(String estadoCivil) {
        this.estadoCivil = estadoCivil;
    }

    public String getSituacionFinanciera() {
        return situacionFinanciera;
    }

    public void setSituacionFinanciera(String situacionFinanciera) {
        this.situacionFinanciera = situacionFinanciera;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public ArrayList<String> getPreferencias() {
        ArrayList<String> prefs = new ArrayList<>();
        prefs.add(getColorFavorito());
        prefs.add(getEmpleo());
        prefs.add(getEstadoCivil());
        prefs.add(getSituacionFinanciera());
        return prefs;
    }

    public void setPreferencias(ArrayList<String> preferencias) {
        this.setColorFavorito(preferencias.get(0));
        this.setEmpleo(preferencias.get(1));
        this.setEstadoCivil(preferencias.get(2));
        this.setSituacionFinanciera(preferencias.get(3));
    }

    public int calcularOfertaAsociada(){

        int ofertaAsociada = 0;
        if(
                (getColorFavorito().equals("Rojo") || getColorFavorito().equals("Rosa") || getColorFavorito().equals("Morado") || getColorFavorito().equals("Blanco")) &&
                (getEstadoCivil().equals("Casado") || getEstadoCivil().equals("Soltero")) &&
                (getSituacionFinanciera().equals("Muy buena") || getSituacionFinanciera().equals("Extremadamente buena"))
        ){ofertaAsociada=1;}//San valentin
        if(
                (getColorFavorito().equals("Naranja") || getColorFavorito().equals("Verde") || getColorFavorito().equals("Blanco")) &&
                (getEmpleo().equals("Profesor") || getEmpleo().equals("Deportista")) &&
                (getSituacionFinanciera().equals("Buena") || getSituacionFinanciera().equals("Normal"))
        ){ofertaAsociada=2;}//Semana santa
        if(
                (getColorFavorito().equals("Azul") || getColorFavorito().equals("Morado") || getColorFavorito().equals("Negro") || getColorFavorito().equals("Amarillo")) &&
                        (getEstadoCivil().equals("Divorciado") || getEstadoCivil().equals("Separado")) &&
                        (getSituacionFinanciera().equals("Normal") || getSituacionFinanciera().equals("Buena") || getSituacionFinanciera().equals("Mala"))
        ){ofertaAsociada=3;}//Reyes magos
        return ofertaAsociada;
    }

    public Usuario(String username, String password){
        this.username=username;
        this.password=password;
    }
}

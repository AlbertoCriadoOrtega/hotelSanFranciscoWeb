package com.example.sanfrancisco21.Session;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.example.sanfrancisco21.R;
import com.example.sanfrancisco21.Usuarios.Usuario;

import java.util.ArrayList;

public class formularioPreferencias extends AppCompatActivity {

    EditText name;EditText lastName;
    Spinner color;Spinner empleo;Spinner estado;Spinner situacion;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.form_layout);

        final Bundle extras = getIntent().getExtras();

        name = findViewById(R.id.form_name);
        lastName = findViewById(R.id.form_lastName);
        color = findViewById(R.id.form_favColor);
        empleo = findViewById(R.id.form_work);
        estado = findViewById(R.id.form_status);
        situacion = findViewById(R.id.form_financies);

        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.spinner1, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        color.setAdapter(adapter);
        adapter = ArrayAdapter.createFromResource(this,
                R.array.spinner2, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        empleo.setAdapter(adapter);
        adapter = ArrayAdapter.createFromResource(this,
                R.array.spinner3, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        estado.setAdapter(adapter);
        adapter = ArrayAdapter.createFromResource(this,
                R.array.spinner4, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        situacion.setAdapter(adapter);

        findViewById(R.id.form_save).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(
                            name.getText().toString().trim().length() != 0 &&
                            lastName.getText().toString().trim().length() != 0
                )
                {
                    BBDD db = new BBDD(formularioPreferencias.this);
                    ArrayList<String> prefs = new ArrayList<>();
                    prefs.add(color.getSelectedItem().toString());
                    prefs.add(empleo.getSelectedItem().toString());
                    prefs.add(estado.getSelectedItem().toString());
                    prefs.add(situacion.getSelectedItem().toString());
                    Usuario usuario = new Usuario(extras.getString("username"),extras.getString("password"));
                    usuario.setPreferencias(prefs);
                    usuario.setNombre(name.getText().toString());
                    usuario.setApellido(lastName.getText().toString());
                    db.addNewUser(usuario);
                    Toast.makeText(formularioPreferencias.this, "Usuario registrado", Toast.LENGTH_SHORT).show();
                    startActivity(new Intent(formularioPreferencias.this, Login.class));
                }
                else{
                    Toast.makeText(formularioPreferencias.this, "Rellene los campos", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}

package com.example.sanfrancisco21.Session;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.sanfrancisco21.MainActivity;
import com.example.sanfrancisco21.R;
import com.example.sanfrancisco21.Usuarios.Usuario;

public class Login extends AppCompatActivity {

    EditText userEdit;EditText passEdit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login_layout);
        BBDD db = new BBDD(Login.this);
        if(db.getAdmin("root","root")==null){
            db.añadirAdministrador();
            db.cargarProductosEnBD();
        }

        userEdit = findViewById(R.id.editTextText1);
        passEdit = findViewById(R.id.editTextTextPassword);

        findViewById(R.id.RegisterBtn).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String user = userEdit.getText().toString().trim();
                String pass = passEdit.getText().toString().trim();
                if(user.equals("") || user.equals(" ") || pass.equals("") || pass.equals(" ") ||
                    user.indexOf(" ") != -1 || pass.indexOf(" ") != -1
                ){
                    Toast.makeText(Login.this, "Rellene los campos correctamente", Toast.LENGTH_SHORT).show();
                }
                else {
                    if(db.getUser(user) != null || db.getAdmin(user,pass) != null ){
                        Intent intent = new Intent(Login.this, MainActivity.class);
                        intent.putExtra("username",user);
                        Usuario usuario = db.getUser(user);
                        if(db.getUser(user) != null){intent.putExtra("oferta",""+usuario.calcularOfertaAsociada());}
                        startActivity(intent);
                    }
                    else{
                        Toast.makeText(Login.this, "Usuario o contraseña mal", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });

        findViewById(R.id.textView4).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Login.this.startActivity(new Intent(Login.this, Register.class));
            }
        });
    }
}
package com.example.sanfrancisco21.Session;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.sanfrancisco21.R;

public class Register extends AppCompatActivity {



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.register_layout);

        findViewById(R.id.RegisterBtn).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String user = ((TextView)findViewById(R.id.editTextText1)).getText().toString().trim();
                String pass = ((TextView)findViewById(R.id.editTextTextPassword)).getText().toString().trim();
                String passCopy = ((TextView)findViewById(R.id.editTextText2)).getText().toString().trim();

                if(user.equals("") || user.equals(" ") || pass.equals("") || pass.equals(" ") ||
                        user.indexOf(" ") != -1 || pass.indexOf(" ") != -1 || !pass.equals(passCopy)
                ){
                    Toast.makeText(Register.this, "Rellene los campos correctamente", Toast.LENGTH_SHORT).show();
                }
                else {
                    BBDD db = new BBDD(Register.this);
                    Intent intent = new Intent(Register.this, formularioPreferencias.class);
                    intent.putExtra("username",user);
                    intent.putExtra("password",pass);
                    startActivity(intent);
                }
            }
        });
    }
}

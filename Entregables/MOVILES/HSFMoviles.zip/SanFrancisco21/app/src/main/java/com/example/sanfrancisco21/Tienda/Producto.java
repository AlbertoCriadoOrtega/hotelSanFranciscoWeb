package com.example.sanfrancisco21.Tienda;

public class Producto {

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public Integer getPrecioProduccion() {
        return precioProduccion;
    }

    public void setPrecioProduccion(Integer precioProduccion) {
        this.precioProduccion = precioProduccion;
    }

    public Integer getPrecioVenta() {
        return precioVenta;
    }

    public void setPrecioVenta(Integer precioVenta) {
        this.precioVenta = precioVenta;
    }

    public Integer getId() {
        return Id;
    }

    public void setId(Integer id) {
        Id = id;
    }

    public Integer getBeneficio() {
        this.beneficio = this.precioVenta - this.precioProduccion;
        return this.beneficio;
    }

    public void setBeneficio(Integer beneficio) {
        this.beneficio = beneficio;
    }

    public String getOfertaAsociada() {
        return ofertaAsociada;
    }

    public void setOfertaAsociada(String ofertaAsociada) {
        this.ofertaAsociada = ofertaAsociada;
    }

    String ofertaAsociada;
    Integer beneficio;
    Integer Id;
    String nombre;
    String descripcion;
    Integer precioProduccion;
    Integer precioVenta;

    public Producto(String nombre, String descripcion, Integer precioProduccion, Integer precioVenta){
        this.nombre=nombre;
        this.descripcion=descripcion;
        this.precioProduccion=precioProduccion;
        this.precioVenta=precioVenta;
        this.beneficio=precioVenta-precioProduccion;
    }
}

package com.example.sanfrancisco21.Session;

import android.content.ContentValues;
import android.content.Context;
import android.content.res.Resources;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.Toast;

import com.example.sanfrancisco21.Tienda.Producto;
import com.example.sanfrancisco21.R;
import com.example.sanfrancisco21.Usuarios.Administrador;
import com.example.sanfrancisco21.Usuarios.Usuario;

import java.util.ArrayList;
import java.util.Collections;

public class BBDD extends SQLiteOpenHelper {

    private Context context;
    private String database;

    public BBDD(Context context) {
        super(context, "Sprint2Movil", null, 1);
        this.database ="Sprint2Movil";
        this.context = context;
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String tabla_usuarios = "create table " + "Usuarios" + " ("
                + "Id_usuario" + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + "Username" + " TEXT,"
                + "Password" + " TEXT,"
                + "Nombre" + " TEXT,"
                + "Apellido" + " TEXT"+")";

        String tabla_preferencias = "create table " + "Preferencias" + " ("
                + "Id_preferencias" + " INTEGER PRIMARY KEY, "
                + "ColorFavorito" + " TEXT,"
                + "Empleo" + " TEXT,"
                + "EstadoCivil" + " TEXT,"
                + "SituacionFinanciera" + " TEXT"+")";

        String tabla_productos = "create table " + "Productos" + " ("
                + "Id_productos" + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + "Nombre" + " TEXT,"
                + "Descripcion" + " TEXT,"
                + "CosteProduccion" + " INTEGER,"
                + "PrecioVenta" + " INTEGER,"
                + "Beneficio" + " INTEGER,"
                + "Oferta" + " TEXT"+")";

        String tabla_administradores = "create table " + "Administradores" + " ("
                + "Id_administrador" + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + "Username" + " TEXT,"
                + "Password" + " TEXT"+")";

        db.execSQL(tabla_usuarios);
        db.execSQL(tabla_administradores);
        db.execSQL(tabla_preferencias);
        db.execSQL(tabla_productos);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {}

    public void añadirAdministrador(){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("Username","root");
        values.put("Password","root");
        db.insert("Administradores", null, values);
        db.close();
    }

    public void cargarProductosEnBD(){
        ArrayList<String> myResArrayList = new ArrayList<String>();
        Resources res = this.context.getResources();
        Collections.addAll(myResArrayList, res.getStringArray(R.array.products_array));
        for (int i = 0; i<myResArrayList.size(); i++){
            String nombre = myResArrayList.get(i).split(" ")[1].replace("_"," ");
            String descripcion = myResArrayList.get(i).split(" ")[2].replace("_"," ");
            Integer precioProduccion = Integer.parseInt(myResArrayList.get(i).split(" ")[3]);
            Integer precioVenta = Integer.parseInt(myResArrayList.get(i).split(" ")[4]);
            String ofertaAsociada = myResArrayList.get(i).split(" ")[5];
            Producto producto = new Producto(nombre,descripcion,precioProduccion,precioVenta);
            if(!ofertaAsociada.equals("")){
                producto.setOfertaAsociada(ofertaAsociada);
            }else {producto.setOfertaAsociada(null); Toast.makeText(context, ""+myResArrayList.get(i).split(" ")[5], Toast.LENGTH_SHORT).show();}
            addProduct(producto);
        }
    }

    public void addNewUser(Usuario user){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("Username",user.getUsername());
        values.put("Password",user.getPassword());
        values.put("Nombre",user.getNombre());
        values.put("Apellido",user.getApellido());
        db.insert("Usuarios", null, values);
        db.close();
        addUserPreferences(user);
    }
    public void addUserPreferences(Usuario user){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("ColorFavorito",user.getPreferencias().get(0));
        values.put("Empleo",user.getPreferencias().get(1));
        values.put("EstadoCivil",user.getPreferencias().get(2));
        values.put("SituacionFinanciera",user.getPreferencias().get(3));
        db.insert("Preferencias", null, values);
        db.close();
    }
    public void addProduct(Producto producto){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("Nombre",producto.getNombre());
        values.put("Descripcion",producto.getDescripcion());
        values.put("CosteProduccion",producto.getPrecioProduccion());
        values.put("PrecioVenta",producto.getPrecioVenta());
        values.put("Beneficio",producto.getBeneficio());
        values.put("Oferta",producto.getOfertaAsociada());
        db.insert("Productos", null, values);
        db.close();
    }
    public Usuario getUser(String username){
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor c = db.rawQuery("select * from Usuarios", null);
        if (c.moveToFirst()){
            do {
               if(c.getString(1).equals(username)){
                   Usuario user = new Usuario(c.getString(1),c.getString(2));
                   user.setId(c.getString(0));
                   user.setNombre(c.getString(3));
                   user.setApellido(c.getString(4));
                   user.setPreferencias(getUserPreferences(Integer.parseInt(user.getId())));
                   return user;
               }
            } while(c.moveToNext());
        }
        c.close();
        return null;
    }

    public Administrador getAdmin(String username, String password){
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor c = db.rawQuery("select * from Administradores", null);
        if (c.moveToFirst()){
            do {
                if(c.getString(1).equals(username) && c.getString(2).equals(password)){
                    Administrador admin = new Administrador(c.getString(1),c.getString(2));
                    admin.setId(Integer.parseInt(c.getString(0)));
                    return admin;
                }
            } while(c.moveToNext());
        }
        c.close();
        return null;
    }

    public ArrayList<String> getUserPreferences(int userId){
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor c = db.rawQuery("select * from Preferencias", null);
        ArrayList<String> prefs = new ArrayList<>();
        if (c.moveToFirst()){
            do {
                if(Integer.parseInt(c.getString(0))==userId)
                {
                    prefs.add(c.getString(1));
                    prefs.add(c.getString(2));
                    prefs.add(c.getString(3));
                    prefs.add(c.getString(4));
                    return prefs;
                }
            } while(c.moveToNext());
        }
        c.close();
        return null;
    }

    public ArrayList<Usuario> getUserList(){
        ArrayList<Usuario> content = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor c = db.rawQuery("select * from Usuarios", null);
        if (c.moveToFirst()){
            do {
                Usuario user = new Usuario(c.getString(1),c.getString(2));
                user.setId(c.getString(0));
                content.add(user);
            } while(c.moveToNext());
            return content;
        }
        c.close();
        return null;
    }

    public ArrayList<Producto> getProductList(){
        ArrayList<Producto> productos = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor c = db.rawQuery("select * from Productos order by Beneficio DESC", null);
        if (c.moveToFirst()){// 0: ID, 1: nombre, 2: descripcion, 3: precioProduccion, 4: PrecioVenta, 5: Beneficio, 6: OfertaAsociada
            do {
                Producto producto = new Producto(c.getString(1),c.getString(2),Integer.parseInt(c.getString(3)),Integer.parseInt(c.getString(4)));
                producto.setId(Integer.parseInt(c.getString(0)));
                producto.setOfertaAsociada(c.getString(6));
                productos.add(producto);
            } while(c.moveToNext());
            return productos;
        }
        c.close();
        return null;
    }

    public void deleteUser(Usuario user){
        SQLiteDatabase db = this.getReadableDatabase();
        db.delete("Usuarios", "Username" + "=?", new String[]{""+user.getUsername()});
        db.close();
    }

}

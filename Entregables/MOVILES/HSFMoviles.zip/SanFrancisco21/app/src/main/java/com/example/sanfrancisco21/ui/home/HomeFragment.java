package com.example.sanfrancisco21.ui.home;

import android.graphics.Typeface;
import android.os.Build;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;

import com.example.sanfrancisco21.MainActivity;
import com.example.sanfrancisco21.R;
import com.example.sanfrancisco21.RoundedButton;
import com.example.sanfrancisco21.databinding.ActivityMainBinding;
import com.google.android.material.navigation.NavigationView;

public class HomeFragment extends Fragment {

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    public HomeFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment SanvalentinFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static HomeFragment newInstance(String param1, String param2) {
        HomeFragment fragment = new HomeFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_home, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        final NavController navController = Navigation.findNavController(view);
        MainActivity mainActivity = (MainActivity) getActivity();

        view.findViewById(R.id.oferta_1_btn).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mainActivity.setOfertaAsociada("1");
                navController.navigate(R.id.tiendaFragment);
            }
        });

        view.findViewById(R.id.oferta_2_btn).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mainActivity.setOfertaAsociada("2");
                navController.navigate(R.id.tiendaFragment);
            }
        });

        view.findViewById(R.id.oferta_3_btn).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mainActivity.setOfertaAsociada("3");
                navController.navigate(R.id.tiendaFragment);
            }
        });

        if(mainActivity.getOfertaAsociada()!="0"){
            buildHomeForOfferUser(view,navController,mainActivity.getOfertaAsociada());
        }
    }

    public void buildHomeForOfferUser(View view, NavController navController,String offerIndex){

        // get views
        LinearLayout Imglayout = view.findViewById(R.id.home_img_layout);
        LinearLayout Textlayout = view.findViewById(R.id.home_titulos_ofertas);
        Textlayout.setPadding(5,0,5,0);
        LinearLayout Btnlayout = view.findViewById(R.id.home_btn_layout);
        ImageButton imgOferta = new ImageButton(getActivity());
        TextView tituloOferta = new TextView(getActivity());
        LinearLayout ofertaContainer = view.findViewById(R.id.oferta_container_layout);
        ofertaContainer.setPadding(5,0,5,5);
        switch (offerIndex){
            case "1":
                // clear views
                ofertaContainer.removeAllViews();
                Imglayout.removeAllViews();Textlayout.removeAllViews();Btnlayout.removeAllViews();

                // setup elements
                tituloOferta.setText("Revisa nuestra tienda de productos por San Valentín:");
                tituloOferta.setTextSize(25);
                tituloOferta.setTypeface(null, Typeface.BOLD_ITALIC);
                tituloOferta.setTextColor(getResources().getColor(R.color.white));
                tituloOferta.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
                imgOferta.setBackground(getResources().getDrawable(R.drawable.sanvalentin));
                imgOferta.setMinimumWidth(1100);
                imgOferta.setMinimumHeight(400);
                imgOferta.getAdjustViewBounds();
                imgOferta.setScaleType(ImageView.ScaleType.FIT_CENTER);
                imgOferta.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        navController.navigate(R.id.tiendaFragment);
                    }
                });

                //Separador
                LinearLayout separador = new LinearLayout(getActivity());
                separador.setBackgroundColor(getResources().getColor(R.color.dorado));
                separador.setMinimumHeight(7);
                LinearLayout.LayoutParams separadorLP1 = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
                separadorLP1.setMargins(0,50,0,25);
                separador.setLayoutParams(separadorLP1);

                // add views
                Imglayout.addView(imgOferta);Textlayout.addView(tituloOferta);
                ofertaContainer.addView(separador);ofertaContainer.addView(Imglayout);
                break;

            case "2":
                // clear views
                ofertaContainer.removeAllViews();
                Imglayout.removeAllViews();Textlayout.removeAllViews();Btnlayout.removeAllViews();

                // setup elements
                tituloOferta.setText("Revisa nuestra tienda de productos por Semana Santa:");
                tituloOferta.setTextSize(25);
                tituloOferta.setTypeface(null, Typeface.BOLD_ITALIC);
                tituloOferta.setTextColor(getResources().getColor(R.color.white));
                tituloOferta.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
                imgOferta.setBackground(getResources().getDrawable(R.drawable.semanasanta));
                imgOferta.setMinimumWidth(1100);
                imgOferta.setMinimumHeight(400);
                imgOferta.getAdjustViewBounds();
                imgOferta.setScaleType(ImageView.ScaleType.FIT_CENTER);
                imgOferta.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        navController.navigate(R.id.tiendaFragment);
                    }
                });

                //Separador
                LinearLayout separador2 = new LinearLayout(getActivity());
                separador2.setBackgroundColor(getResources().getColor(R.color.dorado));
                separador2.setMinimumHeight(7);
                LinearLayout.LayoutParams separadorLP2 = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
                separadorLP2.setMargins(0,50,0,25);
                separador2.setLayoutParams(separadorLP2);

                // add views
                Imglayout.addView(imgOferta);Textlayout.addView(tituloOferta);
                ofertaContainer.addView(separador2);ofertaContainer.addView(Imglayout);
                break;

            case "3":
                // clear views
                ofertaContainer.removeAllViews();
                Imglayout.removeAllViews();Textlayout.removeAllViews();Btnlayout.removeAllViews();

                // setup elements
                tituloOferta.setText("Revisa nuestra tienda de productos por Semana Santa:");
                tituloOferta.setTextSize(25);
                tituloOferta.setTypeface(null, Typeface.BOLD_ITALIC);
                tituloOferta.setTextColor(getResources().getColor(R.color.white));
                tituloOferta.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
                imgOferta.setBackground(getResources().getDrawable(R.drawable.reyesmagos));
                imgOferta.setMinimumWidth(1100);
                imgOferta.setMinimumHeight(400);
                imgOferta.getAdjustViewBounds();
                imgOferta.setScaleType(ImageView.ScaleType.FIT_CENTER);
                imgOferta.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        navController.navigate(R.id.tiendaFragment);
                    }
                });

                //Separador
                LinearLayout separador3 = new LinearLayout(getActivity());
                separador3.setBackgroundColor(getResources().getColor(R.color.dorado));
                separador3.setMinimumHeight(7);
                LinearLayout.LayoutParams separadorLP3 = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
                separadorLP3.setMargins(0,50,0,25);
                separador3.setLayoutParams(separadorLP3);

                // add views
                Imglayout.addView(imgOferta);Textlayout.addView(tituloOferta);
                ofertaContainer.addView(separador3);ofertaContainer.addView(Imglayout);
                break;
            case "0": break;
        }
    }
}